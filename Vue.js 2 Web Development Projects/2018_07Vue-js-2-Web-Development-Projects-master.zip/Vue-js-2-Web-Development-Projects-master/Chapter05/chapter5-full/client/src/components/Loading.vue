<template>
  <div class="loading">
    <div></div>
  </div>
</template>
