export default {
  user: null,
}
