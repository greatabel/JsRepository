```
npm install
npm start
```
