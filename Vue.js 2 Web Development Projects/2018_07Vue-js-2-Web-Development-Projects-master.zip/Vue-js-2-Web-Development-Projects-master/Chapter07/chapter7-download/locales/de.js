export default {
  'change-lang': 'Sprache ändern',
  'lang': {
    'en': 'English',
    'fr': 'Français',
    'es': 'Español',
    'de': 'Deutsch',
  },
  'back': 'Zurück',
}
