export default {
  'change-lang': 'Change language',
  'lang': {
    'en': 'English',
    'fr': 'Français',
    'es': 'Español',
    'de': 'Deutsch',
  },
  'back': 'Back',
}
