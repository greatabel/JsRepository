export default {
  'change-lang': 'Changer de langue',
  'lang': {
    'en': 'English',
    'fr': 'Français',
    'es': 'Español',
    'de': 'Deutsch',
  },
  'back': 'Retour',
}
