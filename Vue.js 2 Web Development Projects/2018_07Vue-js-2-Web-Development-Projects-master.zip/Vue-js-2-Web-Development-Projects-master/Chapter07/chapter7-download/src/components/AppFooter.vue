<template>
  <footer class="app-footer">
    <div>Made with <a href="https://vuejs.org/">Vue.js</a> and ❤️</div>
  </footer>
</template>

<style lang="stylus" scoped>
@import "../styles/imports"

.app-footer
  text-align center
  padding 42px
  color $md-grey-300
</style>
